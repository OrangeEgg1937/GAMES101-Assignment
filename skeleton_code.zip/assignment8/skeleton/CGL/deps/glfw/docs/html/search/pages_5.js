var searchData=
[
  ['notitle',['notitle',['../index.html',1,'']]],
  ['new_20features',['New features',['../news.html',1,'']]]
];
